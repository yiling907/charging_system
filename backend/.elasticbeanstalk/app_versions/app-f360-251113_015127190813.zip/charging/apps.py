from django.apps import AppConfig


class ChargingConfig(AppConfig):
    name = 'charging'
